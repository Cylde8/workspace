# Proyecto sobre estructuras de datos en python: Listas, tuplas, diccionarios y conjuntos 
# Sistema de Bases de Datos para almacenar información de usuarios
# En este proyecto usarás listas y diccionarios
# Partiremos de la definición del diccionario para almacenar la base de datos (usuarios).
# De cada usuario se guardará su apodo y 4 campos: nombre, ocupacion, hobbies y edad

#Empieza definiendo el diccionario "usuarios"








# A continuación habrá un bucle en donde se evalúe la entrada del usuario 
# Dentro del bucle se le darán al usuario 4 opciones: listar usuarios, añadir un usuario, borrar un usuario, buscar un usuario
# Dependiendo de lo que conteste el usuario se hará lo que dice esa opción.

while True:
    elige_opcion = input("1 - listar usuarios, 2 - añadir un usuario, 3 - borrar un usuario, 4 - buscar un usuario, 5 - salir: ")

